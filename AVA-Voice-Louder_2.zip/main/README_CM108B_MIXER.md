# AVA Coach: CM108B + HFP mixer for Louder H6

Target: ESP-IDF 5.3.1, classic ESP32, Sonocotta Louder Rev H6 / TAS5805M.

## Wiring

CM108B -> ESP32 Louder H6:

- DASCLK / BCLK -> GPIO18
- DALRCK / LRCLK -> GPIO19
- SDOUT / DATA -> GPIO23
- GND -> GND
- DAMCLK / MCLK -> not connected

Existing Louder TAS5805M wiring remains:

- GPIO26 -> BCLK
- GPIO25 -> LRCLK
- GPIO22 -> DATA OUT

## Architecture

Samsung A16 -> powered USB hub -> CM108B -> I2S1 RX (ESP32 slave)
                                            |
Bluetooth HFP mic -> HFP callback -> FIFO --+-> mixer 48 kHz stereo
                                            |
                                            +-> I2S0 TX -> TAS5805M -> speaker

The CM108B input and TAS5805M output intentionally use separate I2S peripherals
because they are separate clock domains.

## Files

- `audio_mixer.c`
- `audio_mixer.h`
- `cm108b_mixer_integration.patch`

Copy `audio_mixer.c/.h` into `main/`, then apply the integration changes.

## Important behavioral change

The HFP callback must NOT write directly to `tx_chan` anymore. It only calls:

    audio_mixer_push_hfp(buf, sz);

The mixer task is the only continuous writer to the TAS5805M I2S TX channel.

## Output rate

Change the Louder/TAS5805M I2S output from 44.1 kHz to **48 kHz**.

This gives an exact HFP conversion ratio:

    16 kHz HFP -> 48 kHz mixer = 3:1

and matches the intended CM108B USB playback rate.

## Latency

- Mixer block: 5 ms
- HFP FIFO: max about 20 ms
- FIFO overflow policy: drop oldest HFP audio instead of accumulating delay
- CM108B is read in 5 ms blocks

This is specifically designed to avoid the earlier "FIFO full -> increasing
echo/latency" behavior.

## First test

1. Boot without HFP and play audio from Samsung to CM108B.
2. Confirm log contains `Mixer running`.
3. Confirm Samsung audio is audible through the Louder speaker.
4. Connect HFP headset.
5. Speak into headset while Samsung audio is playing.
6. Both signals should be audible simultaneously.
7. Watch for `HFP low-latency FIFO dropped ...` warnings.
   Occasional drops under startup/transients are preferable to latency growth;
   continuous drops mean producer/consumer timing needs adjustment.

## Note about CM108B I2S format

The code assumes CM108B playback output is standard Philips I2S, 16-bit stereo,
48 kHz. If your development board straps the CM108B digital interface for a
different serial format, the ESP32 slot configuration must be adjusted.
