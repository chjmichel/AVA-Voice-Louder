#include "audio_mixer.h"

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "driver/i2s_std.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/stream_buffer.h"
#include "freertos/task.h"

static const char *TAG = "AUDIO_MIXER";

/*
 * AVA fixed audio format.
 *
 * CM108B playback is configured as 48 kHz / 16-bit stereo.
 * HFP mSBC PCM is 16 kHz / 16-bit mono.
 * TAS5805M output uses 48 kHz stereo with 32-bit slots.
 */
#define MIX_RATE_HZ                 48000
#define HFP_RATE_HZ                 16000
#define MIX_FRAMES                  240     /* 5 ms @ 48 kHz */
#define HFP_SAMPLES_PER_BLOCK       (MIX_FRAMES / 3) /* 80 samples = 5 ms */
#define USB_BYTES_PER_FRAME         4       /* int16 L + int16 R */
#define USB_BLOCK_BYTES             (MIX_FRAMES * USB_BYTES_PER_FRAME)
#define HFP_BLOCK_BYTES             (HFP_SAMPLES_PER_BLOCK * sizeof(int16_t))

/*
 * Keep FIFOs intentionally small. The goal is live monitoring, not lossless
 * buffering. Large queues immediately become audible echo/latency.
 */
#define HFP_FIFO_BYTES              (HFP_BLOCK_BYTES * 4)  /* ~20 ms */
#define USB_READ_TIMEOUT_MS         8
#define HFP_READ_TIMEOUT_MS         0

#ifndef CONFIG_CM108B_BCLK_GPIO
#define CONFIG_CM108B_BCLK_GPIO 18
#endif
#ifndef CONFIG_CM108B_LRCLK_GPIO
#define CONFIG_CM108B_LRCLK_GPIO 19
#endif
#ifndef CONFIG_CM108B_DATA_GPIO
#define CONFIG_CM108B_DATA_GPIO 23
#endif
#ifndef CONFIG_AUDIO_MIX_USB_GAIN_PERCENT
#define CONFIG_AUDIO_MIX_USB_GAIN_PERCENT 70
#endif
#ifndef CONFIG_AUDIO_MIX_HFP_GAIN_PERCENT
#define CONFIG_AUDIO_MIX_HFP_GAIN_PERCENT 70
#endif

static i2s_chan_handle_t s_rx_chan = NULL;
static i2s_chan_handle_t s_tx_chan = NULL;
static StreamBufferHandle_t s_hfp_fifo = NULL;
static TaskHandle_t s_mixer_task = NULL;
static volatile bool s_running = false;

static uint32_t s_hfp_drop_bytes = 0;
static uint32_t s_usb_short_reads = 0;

static inline int16_t clamp16(int32_t v)
{
    if (v > 32767) return 32767;
    if (v < -32768) return -32768;
    return (int16_t)v;
}

/*
 * Drop enough OLD HFP PCM to make room for the newest callback.
 * This is deliberate: when overloaded we prefer a tiny discontinuity over
 * continuously increasing microphone delay / echo.
 */
static void hfp_make_room(size_t needed)
{
    uint8_t scratch[160];

    if (s_hfp_fifo == NULL) {
        return;
    }

    size_t free_bytes = xStreamBufferSpacesAvailable(s_hfp_fifo);
    while (free_bytes < needed) {
        size_t want = needed - free_bytes;
        if (want > sizeof(scratch)) {
            want = sizeof(scratch);
        }

        size_t removed = xStreamBufferReceive(s_hfp_fifo, scratch, want, 0);
        if (removed == 0) {
            break;
        }

        s_hfp_drop_bytes += removed;
        free_bytes = xStreamBufferSpacesAvailable(s_hfp_fifo);
    }
}

void audio_mixer_push_hfp(const uint8_t *data, uint32_t size)
{
    if (!s_running || s_hfp_fifo == NULL || data == NULL || size == 0) {
        return;
    }

    /*
     * StreamBuffer works with bytes, but preserve complete int16 samples.
     */
    size &= ~((uint32_t)1);
    if (size == 0) {
        return;
    }

    if (size > HFP_FIFO_BYTES) {
        data += (size - HFP_FIFO_BYTES);
        size = HFP_FIFO_BYTES;
    }

    hfp_make_room(size);

    size_t sent = xStreamBufferSend(s_hfp_fifo, data, size, 0);
    if (sent < size) {
        s_hfp_drop_bytes += size - sent;
    }

    if (s_hfp_drop_bytes != 0 && (s_hfp_drop_bytes % 3200) < size) {
        ESP_LOGW(TAG, "HFP low-latency FIFO dropped %lu bytes total",
                 (unsigned long)s_hfp_drop_bytes);
    }
}

static void mixer_task(void *arg)
{
    int16_t usb[MIX_FRAMES * 2];
    int16_t hfp[HFP_SAMPLES_PER_BLOCK];
    int32_t out[MIX_FRAMES * 2];

    ESP_LOGI(TAG,
             "Mixer running: USB I2S1 RX GPIO BCLK=%d LRCLK=%d DATA=%d; "
             "48k stereo + HFP 16k mono -> TAS5805M",
             CONFIG_CM108B_BCLK_GPIO,
             CONFIG_CM108B_LRCLK_GPIO,
             CONFIG_CM108B_DATA_GPIO);

    while (s_running) {
        memset(usb, 0, sizeof(usb));
        memset(hfp, 0, sizeof(hfp));

        /*
         * CM108B is the clock master. A normal 5 ms I2S read therefore also
         * provides the pacing for this mixer.
         *
         * If USB audio is absent, timeout and continue with HFP only.
         */
        size_t usb_got = 0;
        esp_err_t rx_ret = i2s_channel_read(
            s_rx_chan,
            usb,
            sizeof(usb),
            &usb_got,
            pdMS_TO_TICKS(USB_READ_TIMEOUT_MS));

        if (rx_ret != ESP_OK || usb_got < sizeof(usb)) {
            if (usb_got < sizeof(usb)) {
                memset(((uint8_t *)usb) + usb_got, 0, sizeof(usb) - usb_got);
            }
            s_usb_short_reads++;
        }

        /*
         * Consume exactly 5 ms HFP if available. Missing microphone samples
         * become silence. This keeps the output live without waiting for HFP.
         */
        size_t hfp_got = 0;
        if (s_hfp_fifo != NULL) {
            hfp_got = xStreamBufferReceive(
                s_hfp_fifo,
                hfp,
                sizeof(hfp),
                pdMS_TO_TICKS(HFP_READ_TIMEOUT_MS));
        }
        if (hfp_got < sizeof(hfp)) {
            memset(((uint8_t *)hfp) + hfp_got, 0, sizeof(hfp) - hfp_got);
        }

        /*
         * 16 -> 48 kHz: exactly 3:1.
         *
         * Linear interpolation between adjacent HFP samples is cheap and avoids
         * the harsher image content of simple 3x sample repetition.
         */
        for (int i = 0; i < MIX_FRAMES; i++) {
            int src = i / 3;
            int phase = i % 3;

            int16_t a = hfp[src];
            int16_t b = (src + 1 < HFP_SAMPLES_PER_BLOCK) ? hfp[src + 1] : a;

            int32_t h;
            if (phase == 0) {
                h = a;
            } else if (phase == 1) {
                h = ((int32_t)a * 2 + b) / 3;
            } else {
                h = ((int32_t)a + (int32_t)b * 2) / 3;
            }

            int32_t l =
                ((int32_t)usb[i * 2] * CONFIG_AUDIO_MIX_USB_GAIN_PERCENT) / 100 +
                (h * CONFIG_AUDIO_MIX_HFP_GAIN_PERCENT) / 100;
            int32_t r =
                ((int32_t)usb[i * 2 + 1] * CONFIG_AUDIO_MIX_USB_GAIN_PERCENT) / 100 +
                (h * CONFIG_AUDIO_MIX_HFP_GAIN_PERCENT) / 100;

            /*
             * Louder H6 currently drives TAS5805M with 32-bit slots, with the
             * signed 16-bit audio in the upper 16 bits.
             */
            out[i * 2]     = ((int32_t)clamp16(l)) << 16;
            out[i * 2 + 1] = ((int32_t)clamp16(r)) << 16;
        }

        size_t written = 0;
        esp_err_t tx_ret = i2s_channel_write(
            s_tx_chan,
            out,
            sizeof(out),
            &written,
            pdMS_TO_TICKS(20));

        if (tx_ret != ESP_OK) {
            ESP_LOGW(TAG, "TAS5805M I2S write failed: %s",
                     esp_err_to_name(tx_ret));
        }
    }

    ESP_LOGI(TAG,
             "Mixer stopped (HFP dropped=%lu bytes, USB short reads=%lu)",
             (unsigned long)s_hfp_drop_bytes,
             (unsigned long)s_usb_short_reads);

    s_mixer_task = NULL;
    vTaskDelete(NULL);
}

esp_err_t audio_mixer_start(i2s_chan_handle_t tx_chan)
{
    if (s_running) {
        return ESP_OK;
    }
    if (tx_chan == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    s_tx_chan = tx_chan;
    s_hfp_drop_bytes = 0;
    s_usb_short_reads = 0;

    if (s_hfp_fifo == NULL) {
        s_hfp_fifo = xStreamBufferCreate(HFP_FIFO_BYTES, 2);
        if (s_hfp_fifo == NULL) {
            return ESP_ERR_NO_MEM;
        }
    } else {
        xStreamBufferReset(s_hfp_fifo);
    }

    /*
     * CM108B is I2S MASTER -> ESP32 I2S1 RX must be SLAVE.
     */
    i2s_chan_config_t chan_cfg =
        I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_SLAVE);

    esp_err_t ret = i2s_new_channel(&chan_cfg, NULL, &s_rx_chan);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Could not allocate I2S1 RX: %s", esp_err_to_name(ret));
        return ret;
    }

    i2s_std_config_t rx_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(MIX_RATE_HZ),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(
            I2S_DATA_BIT_WIDTH_16BIT,
            I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = CONFIG_CM108B_BCLK_GPIO,
            .ws   = CONFIG_CM108B_LRCLK_GPIO,
            .dout = I2S_GPIO_UNUSED,
            .din  = CONFIG_CM108B_DATA_GPIO,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    ret = i2s_channel_init_std_mode(s_rx_chan, &rx_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Could not configure CM108B I2S RX: %s",
                 esp_err_to_name(ret));
        i2s_del_channel(s_rx_chan);
        s_rx_chan = NULL;
        return ret;
    }

    ret = i2s_channel_enable(s_rx_chan);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Could not enable CM108B I2S RX: %s",
                 esp_err_to_name(ret));
        i2s_del_channel(s_rx_chan);
        s_rx_chan = NULL;
        return ret;
    }

    s_running = true;

    BaseType_t ok = xTaskCreatePinnedToCore(
        mixer_task,
        "audio_mixer",
        4096,
        NULL,
        20,
        &s_mixer_task,
        1);

    if (ok != pdPASS) {
        s_running = false;
        i2s_channel_disable(s_rx_chan);
        i2s_del_channel(s_rx_chan);
        s_rx_chan = NULL;
        return ESP_ERR_NO_MEM;
    }

    return ESP_OK;
}

void audio_mixer_stop(void)
{
    if (!s_running && s_rx_chan == NULL) {
        return;
    }

    s_running = false;

    /* Give task enough time to leave a blocking RX/TX call. */
    for (int i = 0; i < 20 && s_mixer_task != NULL; i++) {
        vTaskDelay(pdMS_TO_TICKS(5));
    }

    if (s_rx_chan != NULL) {
        i2s_channel_disable(s_rx_chan);
        i2s_del_channel(s_rx_chan);
        s_rx_chan = NULL;
    }

    if (s_hfp_fifo != NULL) {
        xStreamBufferReset(s_hfp_fifo);
    }

    s_tx_chan = NULL;
}

bool audio_mixer_is_running(void)
{
    return s_running;
}
