#ifndef AVA_AUDIO_MIXER_H
#define AVA_AUDIO_MIXER_H

#include <stdint.h>
#include "esp_err.h"
#include "driver/i2s_std.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Start CM108B + HFP audio mixer.
 *
 * Output format:
 *   48 kHz, stereo, 32-bit I2S slots to TAS5805M.
 *
 * CM108B input:
 *   I2S1 RX slave, 48 kHz, stereo, 16-bit.
 *   BCLK  GPIO18
 *   LRCLK GPIO19
 *   DATA  GPIO23
 */
esp_err_t audio_mixer_start(i2s_chan_handle_t tx_chan);

/** Stop mixer task and CM108B I2S RX. */
void audio_mixer_stop(void);

/**
 * Push HFP microphone PCM into the mixer.
 *
 * Expected HFP format:
 *   16 kHz, mono, signed 16-bit PCM.
 *
 * Non-blocking: if the low-latency FIFO is full the oldest queued audio is
 * allowed to be dropped rather than adding latency.
 */
void audio_mixer_push_hfp(const uint8_t *data, uint32_t size);

/** Returns true while the mixer is running. */
bool audio_mixer_is_running(void);

#ifdef __cplusplus
}
#endif

#endif
